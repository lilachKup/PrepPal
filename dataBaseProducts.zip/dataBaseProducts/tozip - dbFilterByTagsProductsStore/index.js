exports.handler = async (event) => {
    const body = JSON.parse(event.body || '{}');
    const store_ids = body.store_ids;
    const tags = body.tags;
  
    if (!Array.isArray(store_ids) || store_ids.length === 0 ||
        !Array.isArray(tags) || tags.length === 0) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Missing or invalid store_ids/tags' }),
      };
    }
  
    try {
      const products = await getProductsByTagsAndStores(store_ids, tags);
  
      return {
        statusCode: 200,
        body: JSON.stringify(products),
      };
    } catch (err) {
      console.error('DB error:', err);
      return {
        statusCode: 500,
        body: JSON.stringify({ error: 'Internal server error' }),
      };
    }
  };
  