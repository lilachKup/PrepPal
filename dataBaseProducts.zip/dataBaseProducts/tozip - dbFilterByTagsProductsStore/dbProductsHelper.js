const db = require('./db');
const { query } = require("express");


const checkIfStoreExists = async (store_id) => {
    const result = await db.query(
        'SELECT id FROM stores WHERE id = $1', [store_id]
    );
    return result.rows[0] || null;
}

const getProductsByTag = async (store_ids, tags) => {
    const result = await db.query(
        `SELECT p.id, p.name, p.category, p.description, p.tag, p.brand, ps.price, ps.quantity, ps.store_id
         FROM product_store ps
         JOIN products p ON ps.product_id = p.id
         WHERE ps.store_id = ANY($1) 
           AND (${tags.map((_, i) => `p.tag ILIKE '%' || $${i + 2} || '%'`).join(' OR ')})`,
        [store_ids, ...tags]
    );
    return result.rows;
}



module.exports = {
    checkIfStoreExists,
    getProductsByTag
};