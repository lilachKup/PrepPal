const db = require('./db');
const { query } = require("express");


const checkIfStoreExists = async (store_id) => {
    const result = await db.query(
        'SELECT id FROM stores WHERE id = $1', [store_id]
    );
    return result.rows[0] || null;
}

const getProductsByTag = async (store_id, tag) => {
    const result = await db.query(
        `SELECT p.id, p.name, p.category, p.description, p.tag, p.brand, ps.price, ps.quantity, ps.store_id
        FROM product_store ps
        JOIN products p ON ps.product_id = p.id
        WHERE ps.store_id = $1 AND p.tag = $2`, 
        [store_id, tag]
    );
    return result.rows; 
}



module.exports = {
    checkIfStoreExists,
    getProductsByTag
};