const {
    checkIfStoreExists,
    getProductsByStore
  } = require('./dbProductsHelper');
  
  exports.handler = async (event) => {
    const store_id = event.pathParameters.store_id; 
    try {
      const storeExists = await checkIfStoreExists(store_id);
      if (!storeExists) {
        return {
          statusCode: 404,
          body: JSON.stringify({ error: 'Store not found' }),
        };
      }
      const products = await getProductsByStore(store_id);
  
      if (products.length === 0) {
        return {
          statusCode: 404,
          body: JSON.stringify({ error: 'No products found for this store' }),
        };
      }
  
      return {
        statusCode: 200,
        body: JSON.stringify(products),
      };
    } catch (err) {
      console.error('Error fetching products by store:', err);
      return {
        statusCode: 500,
        body: JSON.stringify({ error: 'Database error' }),
      };
    } finally {
      await pool.end();
    }
  };