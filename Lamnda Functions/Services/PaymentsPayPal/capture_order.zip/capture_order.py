import json
import os
import requests

PAYPAL_CLIENT_ID = os.environ["PAYPAL_CLIENT_ID"]
PAYPAL_SECRET = os.environ["PAYPAL_SECRET"]
USE_SANDBOX = os.environ.get("USE_PAYPAL_SANDBOX", "true").lower() == "true"
BASE_URL = "https://api-m.sandbox.paypal.com" if USE_SANDBOX else "https://api-m.paypal.com"


def _response(status_code, body):
    return {
        "statusCode": status_code,
        "body": json.dumps(body),
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "POST, GET, OPTIONS"
        }
    }


def get_access_token():
    try:
        resp = requests.post(
            f"{BASE_URL}/v1/oauth2/token",
            headers={"Accept": "application/json", "Accept-Language": "en_US"},
            data={"grant_type": "client_credentials"},
            auth=(PAYPAL_CLIENT_ID, PAYPAL_SECRET)
        )
        resp.raise_for_status()
        return resp.json()["access_token"]
    except Exception as e:
        raise Exception(f"Error getting access token: {str(e)}")


def get_order(order_id):
    """Check current status of the order"""
    token = get_access_token()
    resp = requests.get(
        f"{BASE_URL}/v2/checkout/orders/{order_id}",
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {token}"}
    )
    resp.raise_for_status()
    return resp.json()


def capture_order(order_id):
    """Capture the order"""
    token = get_access_token()
    resp = requests.post(
        f"{BASE_URL}/v2/checkout/orders/{order_id}/capture",
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {token}"}
    )
    resp.raise_for_status()
    return resp.json()


def lambda_handler(event, context):
    try:
        body = json.loads(event.get("body", "{}"))
        order_id = body.get("order_id")
        if not order_id:
            return _response(400, {"error": "Missing order_id"})

        # 1️⃣ Check order status first
        order_data = get_order(order_id)
        order_status = order_data.get("status")
        if order_status != "APPROVED":
            return _response(200, {"status": order_status})

        # 2️⃣ Capture the order
        capture_data = capture_order(order_id)

        return _response(200, {
            "status": capture_data.get("status"),
            "order_id": order_id
        })

    except requests.exceptions.HTTPError as http_err:
        return _response(http_err.response.status_code, {"error": str(http_err), "response": http_err.response.text})
    except Exception as e:
        return _response(500, {"error": str(e)})
