import json
import os
import requests
import uuid

# ----------------- Env -----------------
PAYPAL_CLIENT_ID = os.environ["PAYPAL_CLIENT_ID"]
PAYPAL_SECRET = os.environ["PAYPAL_SECRET"]
USE_SANDBOX = os.environ.get("USE_PAYPAL_SANDBOX", "true").lower() == "true"
BASE_URL = "https://api-m.sandbox.paypal.com" if USE_SANDBOX else "https://api-m.paypal.com"

# ----------------- Helpers -----------------

def _response(status_code, body):
    return {
        "statusCode": status_code,
        "body": json.dumps(body),
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "POST, GET, OPTIONS"
        }
    }
def get_access_token():
    try:
        resp = requests.post(
            f"{BASE_URL}/v1/oauth2/token",
            headers={"Accept": "application/json", "Accept-Language": "en_US"},
            data={"grant_type": "client_credentials"},
            auth=(PAYPAL_CLIENT_ID, PAYPAL_SECRET)
        )
        resp.raise_for_status()
        return resp.json()["access_token"]
    except Exception as e:
        raise Exception(f"Error getting access token: {str(e)}")


def create_order(products, currency="USD"):
    total_amount = sum(float(p["price"]) * int(p.get("quantity", 1)) for p in products)
    items = [
        {
            "name": p["name"],
            "unit_amount": {"currency_code": currency, "value": f"{float(p['price']):.2f}"},
            "quantity": str(p.get("quantity", 1))
        }
        for p in products
    ]
    payload = {
        "intent": "CAPTURE",
        "purchase_units": [
            {
                "amount": {
                    "currency_code": currency,
                    "value": f"{total_amount:.2f}",
                    "breakdown": {"item_total": {"currency_code": currency, "value": f"{total_amount:.2f}"}}
                },
                "items": items
            }
        ],
        "application_context": {
            "return_url": "https://your-frontend.com/payment-success",
            "cancel_url": "https://your-frontend.com/payment-cancel"
        }
    }
    token = get_access_token()
    resp = requests.post(
        f"{BASE_URL}/v2/checkout/orders",
        json=payload,
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {token}"}
    )
    resp.raise_for_status()
    order = resp.json()
    approval_url = next(link["href"] for link in order["links"] if link["rel"] == "approve")
    return order["id"], approval_url

# ----------------- Lambda -----------------
def lambda_handler(event, context):
    try:
        body = json.loads(event.get("body", "{}"))
        products = body.get("products")
        currency = body.get("currency", "USD")

        if not products or not isinstance(products, list):
            return {"statusCode": 400, "body": json.dumps({"error": "Invalid or empty products list"})}

        order_id, approval_url = create_order(products, currency)
        return _response(200, {"order_id": order_id, "approval_url": approval_url})

    except Exception as e:
        return _response(500, {"error": str(e)})
